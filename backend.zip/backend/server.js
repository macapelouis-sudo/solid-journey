const express = require("express");
const cors = require("cors");
const bcrypt = require("bcryptjs");
const crypto = require("crypto");
const fs = require("fs");
const os = require("os");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 5000;
app.use(cors());
app.use(express.json({ limit: "1mb" }));

const accountDirectory = process.env.LOCALAPPDATA
  ? path.join(process.env.LOCALAPPDATA, "BIMS-MOCAG")
  : path.join(os.homedir(), ".bims-mocag");
const accountFile = path.join(accountDirectory, "accounts.json");

function loadAccounts() {
  try {
    const saved = JSON.parse(fs.readFileSync(accountFile, "utf8"));
    if (!Array.isArray(saved)) throw new Error("Saved accounts must be an array.");
    return saved;
  } catch (error) {
    if (error.code === "ENOENT") return [];
    throw error;
  }
}

function saveAccounts() {
  fs.mkdirSync(accountDirectory, { recursive: true });
  const temporaryFile = `${accountFile}.${process.pid}.tmp`;
  fs.writeFileSync(temporaryFile, JSON.stringify(accounts, null, 2), { encoding: "utf8", mode: 0o600 });
  fs.renameSync(temporaryFile, accountFile);
}

// Service data is in memory; account records are stored in the current user's local app data.
// For production, replace this with a database and real session authentication.
const residents = [
  "Yna Mariah Israel","Khen Lasaca","AJ Macapulay","Cesar Israel","Jed Lagoc",
  "Jazel Mercado","Ken Lester Nonat","Lowie Bosque","Adrian Manzano","Joana Bautista",
  "Hazel Dilla","Louise Zyril U. Macape","John Waren Cabatan","Ernest Cabatan",
  "Vincent Jhon Dumlao","Christian Udaundo","Rowena Rodriguez","Fernando Venus",
  "Albert Barcena"
].map((name, i) => ({
  id: `MOCAG-${String(i+1).padStart(4,"0")}`, name, email: "",
  purok: "", role: ["Albert Barcena","Vincent Jhon Dumlao","Rowena Rodriguez","Fernando Venus","Christian Udaundo"].includes(name) ? "official" : "resident"
}));

const officials = [
  { name:"Albert Barcena", position:"Barangay Captain" },
  { name:"Vincent Jhon Dumlao", position:"SK Chairman" },
  { name:"Rowena Rodriguez", position:"Barangay Secretary" },
  { name:"Fernando Venus", position:"Barangay Auditor" },
  { name:"Christian Udaundo", position:"SK Official" }
];

const announcements = [
  ["Clean and Green Mocag","Join the community clean-up drive this Saturday. Please bring reusable tools and water."],
  ["Barangay Assembly","All residents are invited to the upcoming barangay assembly. Details will be posted by the office."],
  ["Health Center Schedule","Check the Health Services page for the latest consultation schedule."],
  ["Community Service Registration","Registration for community service activities is now open."],
  ["Peace and Order Reminder","Let us keep our community peaceful, respectful, and safe."],
  ["Waste Segregation","Please segregate biodegradable, recyclable, and residual waste."],
  ["Youth Activities","Youth activities and SK updates will be announced here."],
  ["Senior Citizen Assistance","Qualified residents may inquire at the barangay office for assistance."],
  ["PWD Support","Residents may contact the barangay for accessible services and referrals."],
  ["Emergency Contacts","Keep barangay emergency contact information available."],
  ["Water Conservation","Help conserve water and report leaks to the proper office."],
  ["Road Safety","Observe speed limits and use safe pedestrian practices."],
  ["Family Welfare","Barangay referrals and family support information are available."],
  ["Public Service Advisory","Please follow official barangay announcements for verified updates."],
  ["Office Hours","Visit or contact the barangay office during its posted service hours."]
].map((x,i)=>({id:i+1,title:x[0],body:x[1],date:new Date().toISOString().slice(0,10),category:"General"}));

const certificates = [
  {name:"Barangay Certificate of Residency",requirements:["Valid ID or other accepted identity proof","Proof of residence, if available","Complete request form"],steps:["Submit your request online.","Wait for barangay staff to review your residency details.","Follow any verification instructions from the office.","Visit the barangay hall when notified.","Present required documents and pay the official fee, if applicable.","Receive the certificate after approval."]},
  {name:"Certificate of Indigency",requirements:["Valid ID or accepted identity proof","Household and purpose details","Additional documents requested by the barangay"],steps:["Submit the request and state its purpose.","Barangay staff review the information.","Attend an interview or assessment if required.","Wait for approval and release instructions.","Claim the certificate at the barangay hall."]},
  {name:"Certificate of Good Moral Character",requirements:["Valid ID","Complete request form","Purpose of request"],steps:["Submit the request.","Staff check available barangay records.","Provide clarification if requested.","Wait for approval.","Claim the certificate when notified."]},
  {name:"First-Time Job Seeker Certificate",requirements:["Valid ID","Proof of first-time job seeker status, as required","Complete request form"],steps:["Choose this certificate and submit the form.","Present documents required by the office.","Staff verify eligibility and records.","Wait for approval.","Claim the certificate."]},
  {name:"Certificate of Unemployment",requirements:["Valid ID","Complete request form","Supporting information, if requested"],steps:["Submit your request.","Barangay staff review your information.","Provide additional proof if required.","Wait for approval.","Claim at the barangay hall."]},
  {name:"Certificate of No Income",requirements:["Valid ID","Complete request form","Supporting documents, if requested"],steps:["Submit the request with its purpose.","Staff review the information.","Complete any required assessment.","Wait for approval.","Claim the certificate."]},
  {name:"Certificate of Actual Residency",requirements:["Valid ID","Address details","Proof of residence, if available"],steps:["Submit your request.","Staff verify your address.","Cooperate with verification if required.","Wait for approval.","Claim the certificate."]},
  {name:"Certificate of Purok Residency",requirements:["Valid ID","Purok/Zone information","Proof of residence, if available"],steps:["Submit the request and identify your purok.","Staff verify the details.","Provide clarification if needed.","Wait for approval.","Claim the certificate."]},
  {name:"Certificate of Community Membership",requirements:["Valid ID","Complete request form"],steps:["Submit the request.","Staff check community records.","Provide supporting information if needed.","Wait for approval.","Claim the certificate."]},
  {name:"Certificate of Length of Residency",requirements:["Valid ID","Residency history","Supporting proof, if available"],steps:["Submit your request and indicate the period.","Staff review records and supporting proof.","Respond to verification questions.","Wait for approval.","Claim the certificate."]},
  {name:"Certificate of Household Membership",requirements:["Valid ID","Household details","Supporting proof, if requested"],steps:["Submit household information.","Staff verify household records.","Provide clarification if needed.","Wait for approval.","Claim the certificate."]},
  {name:"Certificate of Family Composition",requirements:["Valid ID","Names and relationship of household members","Supporting documents, if requested"],steps:["Submit the family details.","Staff review household records.","Complete verification if required.","Wait for approval.","Claim the certificate."]},
  {name:"Certificate of Single Status (if offered)",requirements:["Valid ID","Complete request form","Additional requirements from the office"],steps:["Ask the barangay if this certificate is offered.","Submit the request and required documents.","Staff review the information.","Wait for approval.","Claim the certificate."]},
  {name:"Certificate of Live-In Relationship (if offered)",requirements:["Valid IDs of concerned parties","Complete request form","Additional requirements from the office"],steps:["Confirm availability with the barangay.","Submit required information and documents.","Staff review and verify details.","Wait for approval.","Claim the certificate."]},
  {name:"Certificate of Change of Address (if offered)",requirements:["Valid ID","Old and new address details","Proof of new address, if available"],steps:["Confirm availability with the barangay.","Submit the request and address details.","Staff verify the information.","Wait for approval.","Claim the certificate."]}
];

const communityServices = [
  "Social Welfare and Financial Assistance Referral","Medical Assistance Referral","Educational Assistance / Scholarship Information",
  "Senior Citizen Assistance","PWD Assistance and Referral","Solo Parent Support","Women and Children Protection Referral",
  "Family Welfare Support","Food Assistance / Relief Goods","Community Clean-Up","Youth and Sports Activities",
  "Livelihood Information","Disaster Preparedness and Relief","Community Volunteer Registration"
];
const healthServices = [
  "Primary Care Consultation","Blood Pressure Screening (if available)","Blood Glucose Screening (if available)",
  "Maternal / Prenatal Consultation","Postpartum and Breastfeeding Support","Child Immunization (schedule-based)",
  "Child Growth and Nutrition Screening","Adolescent Health Education","Family Planning Information",
  "First Aid and Referral","Home Visit / Follow-up (when available)","Health Appointment"
];

const accounts = loadAccounts();
const requests = [];
const reports = [
  ["Roadside drainage needs clearing","Demo report: Residents have requested that the roadside drainage be checked and cleared to improve water flow during rain.","Infrastructure"],
  ["Streetlight near the community hall","Demo report: Please check the streetlight near the community hall; the area may need additional lighting.","Infrastructure"],
  ["Waste collection schedule","Demo report: Residents are asking for a reminder of the regular waste collection schedule.","Environment"],
  ["Litter along the creek path","Demo report: A community clean-up of litter along the creek path has been suggested.","Environment"],
  ["Pothole on the main access road","Demo report: Please inspect the reported pothole on the main access road and advise if repairs are needed.","Infrastructure"],
  ["Request for a pedestrian crossing sign","Demo report: Residents have suggested adding a visible pedestrian crossing reminder near the busy road.","Peace and Order"],
  ["Community clean-up coordination","Demo report: Volunteers are requesting coordination and information about the next community clean-up.","Environment"],
  ["Overgrown plants beside the footpath","Demo report: Please check whether plants beside the footpath need trimming for safer passage.","Infrastructure"],
  ["Water interruption information","Demo report: Residents would appreciate updates when a scheduled water service interruption is expected.","General"],
  ["Request for a first-aid orientation","Demo report: Residents have expressed interest in a basic community first-aid orientation.","Health"],
  ["Safer crossing near the school route","Demo report: Please assess whether additional safety reminders are needed along the school walking route.","Peace and Order"],
  ["Drain cover inspection","Demo report: A drain cover along a commonly used walkway may need inspection for safe pedestrian access.","Infrastructure"],
  ["Recycling information for households","Demo report: Residents are requesting guidance on sorting recyclable household waste.","Environment"],
  ["Community notice board update","Demo report: Please review whether the community notice board needs updated service and contact information.","General"],
  ["Request for a blood pressure screening day","Demo report: Residents are interested in learning whether a community blood pressure screening can be scheduled.","Health"],
  ["Traffic awareness near the barangay hall","Demo report: Residents have suggested sharing a reminder about careful driving near the barangay hall.","Peace and Order"],
  ["Public area cleanliness check","Demo report: Please check whether the shared public area needs additional waste bins or a clean-up schedule.","Environment"],
  ["Emergency contact information","Demo report: Residents are requesting an updated list of official barangay emergency contacts.","General"],
  ["Footpath surface inspection","Demo report: Please inspect the uneven section of the footpath and advise whether maintenance is needed.","Infrastructure"],
  ["Request for a community health advisory","Demo report: Residents would welcome a barangay health advisory with current clinic schedules and service information.","Health"]
].map(([title,description,category],index)=>({
  id:index+1,
  code:`RPT-DEMO-${String(index+1).padStart(3,"0")}`,
  title,
  description,
  category,
  author:"Demo Sample",
  authorId:null,
  date:new Date(Date.now()-(index+1)*86400000).toISOString(),
  status:"Submitted",
  comments:[]
}));
const messages = [];
const notifications = [];
let requestSeq = 1, reportSeq = reports.length + 1, messageSeq = 1;

function cleanText(value="") { return String(value).trim().slice(0,500); }
function makeId(prefix) { return `${prefix}-${crypto.randomBytes(3).toString("hex").toUpperCase()}`; }
function publicAccount(a) { const {passwordHash,...safe}=a; return safe; }
function findAccount(email) { return accounts.find(a=>a.email.toLowerCase()===String(email||"").toLowerCase()); }
function isBadWord(text) {
  const normalized = String(text).toLowerCase().replace(/[^a-z0-9]/g,"");
  const blocked = ["ukkinnam","tanga","duldog","fuck","fuckyou","fucku","tanginamo","tanginamo","tanginamo","tanginamo","tanginam","putangina"];
  return blocked.some(w=>normalized.includes(w));
}
function auth(req,res,next) {
  const id=req.headers["x-user-id"];
  const account=accounts.find(a=>a.id===id);
  if(!account) return res.status(401).json({error:"Please log in to continue."});
  req.user=account; next();
}
function official(req,res,next) {
  if(req.user.role!=="official") return res.status(403).json({error:"Only barangay officials can perform this action."});
  next();
}

app.get("/api/health",(_,res)=>res.json({ok:true,service:"BIMS – MOCAG API"}));
app.get("/api/initial",(_,res)=>res.json({officials,announcements,certificates,communityServices,healthServices,residentCount:residents.length}));

app.post("/api/register",async(req,res)=>{
  const d=req.body||{};
  const required=["firstName","lastName","dob","sex","civilStatus","nationality","phone","email","purok","occupation","password"];
  if(required.some(k=>!String(d[k]||"").trim())) return res.status(400).json({error:"Please complete all required fields."});
  if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(d.email)) return res.status(400).json({error:"Enter a valid email address."});
  if(d.password.length<8) return res.status(400).json({error:"Password must be at least 8 characters."});
  if(findAccount(d.email)) return res.status(409).json({error:"This email is already registered."});
  const fullName=[d.firstName,d.middleName,d.lastName,d.suffix].filter(Boolean).join(" ");
  const match=residents.find(r=>r.name.toLowerCase()===fullName.toLowerCase());
  if(!match) return res.status(403).json({error:"Your name is not on the demo resident registry. Please contact the barangay office for verification."});
  const passwordHash=await bcrypt.hash(d.password,10);
  const account={id:match.id,name:match.name,email:d.email,role:match.role,firstName:d.firstName,middleName:d.middleName,lastName:d.lastName,suffix:d.suffix||"",dob:d.dob,sex:d.sex,civilStatus:d.civilStatus,nationality:d.nationality,religion:d.religion||"",phone:d.phone,purok:d.purok,occupation:d.occupation,placeOfBirth:d.placeOfBirth||"",passwordHash};
  match.email=d.email; match.purok=d.purok;
  accounts.push(account);
  saveAccounts();
  res.status(201).json({user:publicAccount(account),message:"Account created. Welcome to BIMS – MOCAG!"});
});
app.post("/api/login",async(req,res)=>{
  const a=findAccount(req.body?.email);
  if(!a||!await bcrypt.compare(String(req.body?.password||""),a.passwordHash)) return res.status(401).json({error:"Incorrect email or password."});
  res.json({user:publicAccount(a)});
});
app.get("/api/me",auth,(req,res)=>res.json({user:publicAccount(req.user)}));

app.get("/api/residents",auth,(req,res)=>{
  // Residents see the directory names only; officials see the full registry.
  res.json(req.user.role==="official"?residents:residents.map(r=>({id:r.id,name:r.name,role:r.role})));
});
app.get("/api/officials",auth,(_,res)=>res.json(officials));
app.get("/api/announcements",auth,(_,res)=>res.json(announcements));
app.post("/api/announcements",auth,official,(req,res)=>{
  const item={id:announcements.length+1,title:cleanText(req.body.title),body:cleanText(req.body.body),date:new Date().toISOString().slice(0,10),category:cleanText(req.body.category||"General")};
  if(!item.title||!item.body)return res.status(400).json({error:"Title and announcement details are required."});
  announcements.unshift(item);res.status(201).json(item);
});

app.get("/api/reports",auth,(_,res)=>res.json(reports));
app.post("/api/reports",auth,(req,res)=>{
  const title=cleanText(req.body.title),description=cleanText(req.body.description);
  if(!title||!description)return res.status(400).json({error:"Please enter a title and description."});
  if(isBadWord(title+" "+description))return res.status(400).json({error:"Please remove inappropriate language before submitting."});
  const item={id:reportSeq++,code:makeId("RPT"),title,description,category:cleanText(req.body.category||"General"),author:req.user.name,authorId:req.user.id,date:new Date().toISOString(),status:"Submitted",comments:[]};
  reports.unshift(item);res.status(201).json(item);
});
app.post("/api/reports/:id/comments",auth,(req,res)=>{
  const report=reports.find(r=>r.id===Number(req.params.id));if(!report)return res.status(404).json({error:"Report not found."});
  const text=cleanText(req.body.text);if(!text)return res.status(400).json({error:"Comment cannot be empty."});
  if(isBadWord(text))return res.status(400).json({error:"Please remove inappropriate language."});
  report.comments.push({id:Date.now(),author:req.user.name,text,date:new Date().toISOString()});res.status(201).json(report);
});

app.get("/api/requests",auth,(req,res)=>res.json(requests.filter(r=>req.user.role==="official"||r.userId===req.user.id)));
app.post("/api/requests",auth,(req,res)=>{
  const type=cleanText(req.body.type),service=cleanText(req.body.service),purpose=cleanText(req.body.purpose);
  if(!type||!service)return res.status(400).json({error:"Please choose a service."});
  const item={id:requestSeq++,code:makeId("REQ"),type,service,purpose,userId:req.user.id,userName:req.user.name,date:new Date().toISOString(),status:"Pending",notes:"Your request is awaiting barangay review."};
  requests.unshift(item);notifications.unshift({id:Date.now(),userId:req.user.id,text:`Your ${service} request was submitted.`,date:new Date().toISOString(),read:false});
  res.status(201).json(item);
});
app.patch("/api/requests/:id/status",auth,official,(req,res)=>{
  const item=requests.find(r=>r.id===Number(req.params.id));if(!item)return res.status(404).json({error:"Request not found."});
  const allowed=["Pending","Under Review","Approved","Rejected","Ready for Claim","Completed"];
  if(!allowed.includes(req.body.status))return res.status(400).json({error:"Invalid status."});
  item.status=req.body.status;item.notes=cleanText(req.body.notes||"Status updated by barangay staff.");
  notifications.unshift({id:Date.now(),userId:item.userId,text:`Your ${item.service} request is now ${item.status}.`,date:new Date().toISOString(),read:false});
  res.json(item);
});
app.get("/api/notifications",auth,(req,res)=>res.json(notifications.filter(n=>(req.user.role==="official"||n.userId===req.user.id)&&!(n.archivedBy||[]).includes(req.user.id))));
app.get("/api/services",auth,(_,res)=>res.json({communityServices,healthServices,certificates}));

app.get("/api/messages",auth,(req,res)=>res.json(messages.filter(m=>(m.fromId===req.user.id||m.toId===req.user.id)&&!(m.archivedBy||[]).includes(req.user.id))));
app.get("/api/archive",auth,(req,res)=>{
  const archivedNotifications=notifications.filter(n=>(n.archivedBy||[]).includes(req.user.id)).map(item=>({...item,archiveType:"notification"}));
  const archivedMessages=messages.filter(m=>(m.fromId===req.user.id||m.toId===req.user.id)&&(m.archivedBy||[]).includes(req.user.id)).map(item=>({...item,archiveType:"message"}));
  res.json([...archivedNotifications,...archivedMessages].sort((a,b)=>new Date(b.date)-new Date(a.date)));
});
app.patch("/api/archive/:type/:id",auth,(req,res)=>{
  const {type,id}=req.params;
  const item=type==="notification"
    ? notifications.find(n=>String(n.id)===id&&(req.user.role==="official"||n.userId===req.user.id))
    : type==="message"
      ? messages.find(m=>String(m.id)===id&&(m.fromId===req.user.id||m.toId===req.user.id))
      : null;
  if(!item)return res.status(type==="notification"||type==="message"?404:400).json({error:type==="notification"||type==="message"?"Item not found.":"Invalid archive item type."});
  const archivedBy=item.archivedBy||(item.archivedBy=[]);
  if(req.body.archived===true&&!archivedBy.includes(req.user.id))archivedBy.push(req.user.id);
  if(req.body.archived===false)item.archivedBy=archivedBy.filter(userId=>userId!==req.user.id);
  if(typeof req.body.archived!=="boolean")return res.status(400).json({error:"Archived must be true or false."});
  res.json(item);
});
app.post("/api/messages",auth,(req,res)=>{
  const to=accounts.find(a=>a.id===req.body.toId);const text=cleanText(req.body.text);
  if(!to)return res.status(404).json({error:"Recipient must have a registered account."});
  if(!text)return res.status(400).json({error:"Message cannot be empty."});
  if(isBadWord(text))return res.status(400).json({error:"Please use respectful language."});
  const m={id:messageSeq++,fromId:req.user.id,from:req.user.name,toId:to.id,to:to.name,text,date:new Date().toISOString(),archivedBy:[]};messages.push(m);res.status(201).json(m);
});
app.patch("/api/profile",auth,async(req,res)=>{
  const fields=["phone","purok","occupation","religion"];
  fields.forEach(k=>{if(req.body[k]!==undefined)req.user[k]=cleanText(req.body[k]);});
  if(req.body.password){if(req.body.password.length<8)return res.status(400).json({error:"Password must be at least 8 characters."});req.user.passwordHash=await bcrypt.hash(req.body.password,10);}
  saveAccounts();
  res.json({user:publicAccount(req.user)});
});

app.use((err,req,res,next)=>{console.error(err);res.status(500).json({error:"Unexpected server error. Please try again."});});
app.listen(PORT,()=>console.log(`BIMS – MOCAG API running at http://localhost:${PORT}`));
